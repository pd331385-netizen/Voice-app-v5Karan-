package com.example.voiceassistant

import android.annotation.SuppressLint
import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.net.Uri
import android.os.*
import android.provider.AlarmClock
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Locale
import kotlin.concurrent.thread
import kotlin.math.sqrt

/*
 नया तरीका (v2):
 - Android के SpeechRecognizer की जगह माइक सीधे AudioRecord से सुना जाता है (हर फ़ोन पर चलता है, बीप/रीस्टार्ट नहीं)।
 - जब आप बोलते हैं और रुकते हैं, तो वह आवाज़ Gemini को भेजी जाती है। Gemini उसे समझकर जवाब देता है।
 - "हे असिस्टेंट" बोलने की ज़रूरत नहीं, आप कुछ भी बोलें तो जवाब मिलेगा।
 - सर्विस फ़ोरग्राउंड में चलती है, इसलिए ऐप बंद या स्क्रीन ऑफ़ होने पर भी चलती रहती है।
*/
class AssistantService : Service(), TextToSpeech.OnInitListener {

    companion object {
        const val ACTION_TOGGLE = "toggle_game_mode"
        const val CHANNEL = "assistant"
        const val MAX_HISTORY = 20
        const val DEFAULT_MODEL = "gemini-3.5-flash-lite"
        const val SR = 16000
    }

    private lateinit var tts: TextToSpeech
    private var ttsReady = false
    private val handler = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("mem", MODE_PRIVATE) }
    private var wakeLock: PowerManager.WakeLock? = null

    @Volatile private var running = true
    @Volatile private var paused = false   // गेम मोड
    @Volatile private var busy = false     // सोच/बोल रहा हो तो माइक की आवाज़ अनदेखी
    private var status = "सुन रहा हूँ 🎤"

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(CHANNEL, "Assistant", NotificationManager.IMPORTANCE_LOW))
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)

        wakeLock = getSystemService(PowerManager::class.java)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "dhakad:listen").apply { acquire() }

        tts = TextToSpeech(this, this)
        startAudioLoop()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_TOGGLE) {
            paused = !paused
            setStatus(if (paused) "गेम मोड: रुका हुआ" else "सुन रहा हूँ 🎤")
        }
        return START_STICKY
    }

    // ---------- नोटिफ़िकेशन ----------
    private fun buildNotification(): Notification {
        val pi = PendingIntent.getService(
            this, 0,
            Intent(this, AssistantService::class.java).setAction(ACTION_TOGGLE),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val action = Notification.Action.Builder(
            Icon.createWithResource(this, android.R.drawable.ic_media_pause),
            if (paused) "सुनना शुरू करें" else "गेम मोड (रोकें)", pi).build()
        return Notification.Builder(this, CHANNEL)
            .setContentTitle(if (paused) "गेम मोड: असिस्टेंट रुका है" else "धाकड़ असिस्टेंट चालू है")
            .setContentText(status)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .addAction(action)
            .setOngoing(true)
            .build()
    }

    private fun setStatus(s: String) {
        status = s
        handler.post {
            getSystemService(NotificationManager::class.java).notify(1, buildNotification())
        }
    }

    // ---------- आवाज़ (TTS) ----------
    override fun onInit(s: Int) {
        if (s != TextToSpeech.SUCCESS) {
            setStatus("बोलने वाला इंजन नहीं चला: Google Text-to-speech इंस्टॉल करें")
            return
        }
        val r = tts.setLanguage(Locale("hi", "IN"))
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED)
            tts.setLanguage(Locale.getDefault())
        tts.setAudioAttributes(AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ASSISTANT)
            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { listenSoon() }
            override fun onError(id: String?) { listenSoon() }
        })
        ttsReady = true
    }

    private fun say(msg: String) {
        handler.post {
            busy = true
            if (ttsReady && tts.speak(msg, TextToSpeech.QUEUE_FLUSH, null, "u") == TextToSpeech.SUCCESS)
                return@post
            listenSoon() // बोल नहीं पाया, तो वापस सुनने लगो
        }
    }

    /** बोलना ख़त्म होने के थोड़ी देर बाद फिर सुनना शुरू (ताकि अपनी ही आवाज़ न पकड़े) */
    private fun listenSoon() {
        handler.postDelayed({
            busy = false
            setStatus(if (paused) "गेम मोड: रुका हुआ" else "सुन रहा हूँ 🎤")
        }, 700)
    }

    // ---------- माइक सुनना (VAD) ----------
    @SuppressLint("MissingPermission")
    private fun startAudioLoop() {
        thread(name = "audio-loop") {
            android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND)
            val minBuf = AudioRecord.getMinBufferSize(
                SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val rec = try {
                AudioRecord(MediaRecorder.AudioSource.MIC, SR, AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuf, SR * 2))
            } catch (e: Exception) {
                setStatus("माइक नहीं खुला: परमिशन चेक करें"); return@thread
            }
            if (rec.state != AudioRecord.STATE_INITIALIZED) {
                setStatus("माइक की परमिशन/एक्सेस नहीं मिली"); return@thread
            }

            val chunk = ShortArray(1600)           // 100 ms
            val buf = ByteArrayOutputStream()
            val preroll = ArrayDeque<ShortArray>()
            var recording = false
            var inSpeech = false
            var loudRun = 0
            var loudTotal = 0
            var quiet = 0
            var noise = 300.0

            try {
                while (running) {
                    if (paused) {                   // गेम मोड: माइक पूरी तरह छोड़ दो
                        if (recording) { rec.stop(); recording = false }
                        inSpeech = false; buf.reset(); preroll.clear(); loudRun = 0
                        Thread.sleep(300); continue
                    }
                    if (!recording) { rec.startRecording(); recording = true }

                    val n = rec.read(chunk, 0, chunk.size)
                    if (n <= 0) { Thread.sleep(50); continue }
                    if (busy) {                     // सोच/बोल रहा है, आवाज़ अनदेखी
                        inSpeech = false; buf.reset(); preroll.clear(); loudRun = 0
                        continue
                    }

                    var sum = 0.0
                    for (i in 0 until n) sum += chunk[i].toDouble() * chunk[i]
                    val rms = sqrt(sum / n)
                    val loud = rms > maxOf(600.0, noise * 3.5)

                    if (!inSpeech) {
                        if (!loud) noise = noise * 0.97 + rms * 0.03
                        preroll.addLast(chunk.copyOf(n))
                        if (preroll.size > 4) preroll.removeFirst()
                        loudRun = if (loud) loudRun + 1 else 0
                        if (loudRun >= 2) {         // बोलना शुरू हुआ
                            inSpeech = true; quiet = 0; loudTotal = loudRun
                            for (c in preroll) writeShorts(buf, c)
                            preroll.clear()
                        }
                    } else {
                        writeShorts(buf, chunk.copyOf(n))
                        if (loud) { quiet = 0; loudTotal++ } else quiet++
                        // 1 सेकंड की चुप्पी या 20 सेकंड पूरे: बात ख़त्म
                        if (quiet >= 10 || buf.size() > SR * 2 * 20) {
                            val pcm = buf.toByteArray()
                            buf.reset(); inSpeech = false; loudRun = 0
                            if (loudTotal >= 4) {   // बहुत छोटी आवाज़ (खटपट) अनदेखी
                                busy = true
                                setStatus("सोच रहा हूँ…")
                                thread(priority = Thread.MIN_PRIORITY) { processAudio(pcm) }
                            }
                            loudTotal = 0
                        }
                    }
                }
            } catch (e: Exception) {
                setStatus("माइक एरर: ${e.javaClass.simpleName}")
            } finally {
                try { rec.stop() } catch (_: Exception) {}
                rec.release()
            }
        }
    }

    private fun writeShorts(out: ByteArrayOutputStream, s: ShortArray) {
        val bb = ByteBuffer.allocate(s.size * 2).order(ByteOrder.LITTLE_ENDIAN)
        for (v in s) bb.putShort(v)
        out.write(bb.array())
    }

    private fun wav(pcm: ByteArray): ByteArray {
        val h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        h.put("RIFF".toByteArray()); h.putInt(36 + pcm.size); h.put("WAVE".toByteArray())
        h.put("fmt ".toByteArray()); h.putInt(16)
        h.putShort(1); h.putShort(1); h.putInt(SR); h.putInt(SR * 2); h.putShort(2); h.putShort(16)
        h.put("data".toByteArray()); h.putInt(pcm.size)
        return h.array() + pcm
    }

    // ---------- Gemini: आवाज़ समझना + जवाब ----------
    private fun turn(role: String, text: String) = JSONObject().put("role", role)
        .put("parts", JSONArray().put(JSONObject().put("text", text)))

    private fun loadHistory(): JSONArray =
        try { JSONArray(prefs.getString("h", "[]")) } catch (e: Exception) { JSONArray() }

    private fun saveTurn(user: String, model: String) {
        val hist = loadHistory()
        hist.put(turn("user", user)).put(turn("model", model))
        val trimmed = JSONArray()
        for (i in maxOf(0, hist.length() - MAX_HISTORY) until hist.length()) trimmed.put(hist.get(i))
        prefs.edit().putString("h", trimmed.toString()).apply()
    }

    private fun processAudio(pcm: ByteArray) {
        var heard = ""
        var reply = ""
        try {
            val cfg = getSharedPreferences("settings", MODE_PRIVATE)
            val key = cfg.getString("api_key", "")?.trim().orEmpty()
            if (key.isEmpty()) { say("पहले ऐप की सेटिंग में API key डालें"); return }
            val model = cfg.getString("model", DEFAULT_MODEL)?.trim().orEmpty().ifEmpty { DEFAULT_MODEL }
            val url = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent"

            val hist = loadHistory()
            val contents = JSONArray()
            for (i in 0 until hist.length()) contents.put(hist.getJSONObject(i))
            contents.put(JSONObject().put("role", "user").put("parts", JSONArray().put(
                JSONObject().put("inline_data", JSONObject()
                    .put("mime_type", "audio/wav")
                    .put("data", Base64.encodeToString(wav(pcm), Base64.NO_WRAP))))))

            val system = "तुम एक हिंदी वॉइस असिस्टेंट हो और तुम्हें धाकड़ ने बनाया है। " +
                "यूज़र की आवाज़ ऑडियो में आती है। जवाब का फ़ॉर्मेट सख़्ती से यह रखो: " +
                "पहली लाइन में 'सुना: ' लिखकर ऑडियो में जो बोला गया उसका सही टेक्स्ट लिखो। " +
                "दूसरी लाइन से यूज़र की भाषा में 2-3 छोटे वाक्यों का जवाब दो, बिना markdown के। " +
                "अगर ऑडियो में कोई साफ़ इंसानी बोली नहीं है (सिर्फ़ शोर, खामोशी, खटपट), तो पूरे जवाब में सिर्फ़ NONE लिखो। " +
                "पिछली बातचीत याद रखो।"
            val body = JSONObject()
                .put("systemInstruction", JSONObject().put("parts", JSONArray().put(
                    JSONObject().put("text", system))))
                .put("contents", contents)

            val conn = (URL(url).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                setRequestProperty("Content-Type", "application/json")
                setRequestProperty("x-goog-api-key", key)
                doOutput = true; connectTimeout = 15000; readTimeout = 40000
            }
            conn.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = conn.responseCode
            val raw = (if (code in 200..299) conn.inputStream else conn.errorStream)
                .bufferedReader().readText()
            if (code !in 200..299) {
                setStatus("Gemini एरर कोड $code")
                say("जवाब नहीं मिल पाया, एरर कोड $code")
                return
            }

            val parts = JSONObject(raw).getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts")
            val sb = StringBuilder()
            for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text", ""))
            val text = sb.toString().trim()

            if (text.isEmpty() || text.startsWith("NONE")) { listenSoon(); return }
            val lines = text.lines()
            if (lines.first().trim().startsWith("सुना:")) {
                heard = lines.first().substringAfter("सुना:").trim()
                reply = lines.drop(1).joinToString(" ").trim()
            } else {
                reply = text
            }
        } catch (e: Exception) {
            setStatus("एरर: ${e.javaClass.simpleName}")
            say("जवाब नहीं मिल पाया, इंटरनेट चेक करें")
            return
        }
        handler.post { route(heard, reply) }
    }

    private fun route(heard: String, reply: String) {
        if (heard.isNotEmpty()) {
            setStatus("सुना: $heard")
            if (tryCommand(heard.lowercase())) return
        }
        if (reply.isEmpty()) { listenSoon(); return }
        saveTurn(heard.ifEmpty { "(आवाज़)" }, reply)
        say(reply)
    }

    // ---------- फ़ोन के कमांड ----------
    private fun launch(i: Intent) {
        // Android 10+ में बैकग्राउंड से स्क्रीन खोलने के लिए "Display over other apps" परमिशन चाहिए
        startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun number(cmd: String) = Regex("\\d+").find(cmd)?.value?.toIntOrNull()

    /** कमांड मिला तो true (और खुद बोल देता है), वरना false: तब Gemini का जवाब बोला जाएगा */
    private fun tryCommand(cmd: String): Boolean {
        when {
            "किसने बनाया" in cmd || "who made you" in cmd || "तुम्हारा निर्माता" in cmd ->
                say("मुझे धाकड़ ने बनाया है")
            "भूल जाओ" in cmd || "याददाश्त मिटाओ" in cmd -> {
                prefs.edit().remove("h").apply(); say("सब कुछ भूल गया")
            }
            "अलार्म" in cmd || "alarm" in cmd -> {
                val h = number(cmd)
                if (h == null) say("कितने बजे का अलार्म?")
                else {
                    launch(Intent(AlarmClock.ACTION_SET_ALARM).apply {
                        putExtra(AlarmClock.EXTRA_HOUR, h % 24)
                        putExtra(AlarmClock.EXTRA_MINUTES, 0)
                        putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                    })
                    say("$h बजे का अलार्म लगा दिया")
                }
            }
            "टाइमर" in cmd || "timer" in cmd -> {
                val m = number(cmd)
                if (m == null) say("कितने मिनट का टाइमर?")
                else {
                    launch(Intent(AlarmClock.ACTION_SET_TIMER).apply {
                        putExtra(AlarmClock.EXTRA_LENGTH, m * 60)
                        putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                    })
                    say("$m मिनट का टाइमर शुरू")
                }
            }
            "कॉल" in cmd || "call" in cmd -> {
                val n = Regex("\\d{6,}").find(cmd.replace(" ", ""))?.value
                if (n == null) say("नंबर बोलकर कॉल करें")
                else { launch(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$n"))); say("डायल कर रहा हूँ") }
            }
            "खोलो" in cmd || "open " in cmd ->
                openApp(cmd.replace("खोलो", "").replace("open", "").trim())
            "गाना" in cmd || "यूट्यूब" in cmd -> {
                val q = cmd.replace("गाना", "").replace("चलाओ", "").trim()
                launch(Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q))))
                say("यूट्यूब पर खोज रहा हूँ")
            }
            else -> return false
        }
        return true
    }

    private fun openApp(name: String) {
        val pm = packageManager
        val apps = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val pkg = apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(name) }
            ?.activityInfo?.packageName
        val i = pkg?.let { pm.getLaunchIntentForPackage(it) }
        if (i != null) { launch(i); say("$name खोल रहा हूँ") } else say("$name ऐप नहीं मिला")
    }

    override fun onDestroy() {
        running = false
        handler.removeCallbacksAndMessages(null)
        try { tts.shutdown() } catch (_: Exception) {}
        try { wakeLock?.release() } catch (_: Exception) {}
        super.onDestroy()
    }
}
